package org.example.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
public class DeleteProductFrame extends JFrame{
    protected JButton delete;
    protected JTextField idField;
    public DeleteProductFrame(){
        this.setBounds(100, 100, 650, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setBackground(Color.pink);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setLayout(null);
        delete = new JButton("delete");
        delete.setFont(new Font("Tahoma", Font.PLAIN, 12));
        delete.setBounds(370, 350, 100, 25);
        delete.setBackground(Color.MAGENTA);
        this.getContentPane().add(delete);
        delete.setVisible(true);
        JLabel label1 = new JLabel("Id");
        label1.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label1.setBounds(130, 130, 50, 25);
        this.getContentPane().add(label1);
        label1.setVisible(true);
        idField = new JTextField();
        idField.setBounds(200, 130, 250, 25);
        idField.setBackground(Color.pink);
        this.getContentPane().add(idField);
        idField.setColumns(2);
        this.setVisible(true);
    }
    public void setDeleteButtonActionListener(ActionListener a) {
        delete.addActionListener(a);
    }
    public int getIdField(){
        return Integer.parseInt(idField.getText());
    }
}
