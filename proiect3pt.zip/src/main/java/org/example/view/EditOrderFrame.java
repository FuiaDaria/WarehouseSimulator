package org.example.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class EditOrderFrame extends JFrame{
    protected JButton edit;
    protected JTextField costField;
    protected JTextField idcField;
    protected JTextField idField;
    protected JTextField idpField;
    protected JTextField quantityField;
    public EditOrderFrame(){
        this.setBounds(100, 100, 650, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setBackground(Color.pink);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setLayout(null);
        idField = new JTextField();
        idField.setBounds(200, 110, 250, 25);
        idField.setBackground(Color.pink);
        this.getContentPane().add(idField);
        idField.setColumns(2);
        costField = new JTextField();
        costField.setBounds(200, 270, 250, 25);
        costField.setBackground(Color.pink);
        this.getContentPane().add(costField);
        costField.setColumns(2);
        idcField = new JTextField();
        idcField.setBounds(200, 150, 250, 25);
        idcField.setBackground(Color.pink);
        this.getContentPane().add(idcField);
        idcField.setColumns(2);
        idpField = new JTextField();
        idpField.setBounds(200, 190, 250, 25);
        idpField.setBackground(Color.pink);
        this.getContentPane().add(idpField);
        idpField.setColumns(2);
        quantityField = new JTextField();
        quantityField.setBounds(200, 230, 250, 25);
        quantityField.setBackground(Color.pink);
        this.getContentPane().add(quantityField);
        quantityField.setColumns(2);
        edit = new JButton("edit");
        edit.setFont(new Font("Tahoma", Font.PLAIN, 12));
        edit.setBounds(370, 350, 100, 25);
        edit.setBackground(Color.MAGENTA);
        this.getContentPane().add(edit);
        edit.setVisible(true);
        this.setVisible(true);
    }
    public void setEditButtonActionListener(ActionListener a) {
        edit.addActionListener(a);
    }
    public int getIdcField(){
        return Integer.parseInt(idcField.getText());
    }
    public int getIdField(){
        return Integer.parseInt(idField.getText());
    }
    public int getIdpField(){
        return Integer.parseInt(idpField.getText());
    }
    public int getQuantityField() {
        return Integer.parseInt(quantityField.getText());
    }
    public int getCostField(){
        return Integer.parseInt(costField.getText());
    }
}
