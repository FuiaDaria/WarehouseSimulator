package org.example.view;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
public class ViewOrderFrame extends JFrame{
    protected JButton view;
    protected JTextField orders;
    public ViewOrderFrame(){
        this.setBounds(100, 100, 650, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setBackground(Color.pink);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setLayout(null);
        view = new JButton("view all");
        view.setFont(new Font("Tahoma", Font.PLAIN, 12));
        view.setBounds(370, 350, 100, 25);
        view.setBackground(Color.MAGENTA);
        this.getContentPane().add(view);
        view.setVisible(true);
        orders = new JTextField();
        orders.setBounds(200, 130, 250, 60);
        orders.setBackground(Color.pink);
        this.getContentPane().add(orders);
        orders.setColumns(2);
        this.setVisible(true);
    }
    public void setViewButtonActionListener(ActionListener a) {
        view.addActionListener(a);
    }
    public void setOrderField(String text){
        this.orders.setText(text);
    }
}
