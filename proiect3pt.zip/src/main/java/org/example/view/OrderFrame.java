package org.example.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class OrderFrame extends JFrame {
    protected JButton add;
    protected JButton view;
    protected JButton delete;
    protected JButton edit;

    public OrderFrame(){
        this.setBounds(100, 100, 650, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setBackground(Color.pink);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setLayout(null);
        JLabel msLabel = new JLabel("Choose your operation");
        msLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
        msLabel.setBounds(220, 80, 300, 40);
        this.getContentPane().add(msLabel);
        msLabel.setVisible(true);
        add= new JButton("add Order");
        add.setFont(new Font("Tahoma", Font.PLAIN, 12));
        add.setBounds(250, 130, 100, 25);
        add.setBackground(Color.MAGENTA);
        this.getContentPane().add(add);
        add.setVisible(true);
        view = new JButton("view Orders");
        view.setFont(new Font("Tahoma", Font.PLAIN, 12));
        view.setBounds(250, 170, 100, 25);
        view.setBackground(Color.MAGENTA);
        this.getContentPane().add(view);
        view.setVisible(true);
        delete = new JButton("delete Order");
        delete.setFont(new Font("Tahoma", Font.PLAIN, 12));
        delete.setBounds(250, 210, 100, 25);
        delete.setBackground(Color.MAGENTA);
        this.getContentPane().add(delete);
        delete.setVisible(true);
        edit = new JButton("edit Order");
        edit.setFont(new Font("Tahoma", Font.PLAIN, 12));
        edit.setBounds(250, 250, 100, 25);
        edit.setBackground(Color.MAGENTA);
        this.getContentPane().add(edit);
        edit.setVisible(true);
        this.setVisible(true);
    }

    public void setAddButtonActionListener(ActionListener a) {
        add.addActionListener(a);
    }
    public void setEditButtonActionListener(ActionListener a) {
        edit.addActionListener(a);
    }
    public void setDeleteButtonActionListener(ActionListener a) {
        delete.addActionListener(a);
    }
    public void setViewButtonActionListener(ActionListener a) {
        view.addActionListener(a);
    }
}