package org.example.view;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
public class MainFrame extends JFrame {
    protected JButton client;
    protected JButton product;
    protected JButton order;

    public MainFrame() {
        this.setBounds(100, 100, 650, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setBackground(Color.pink);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setLayout(null);

        JLabel msLabel = new JLabel("On what do you want to operate?");
        msLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
        msLabel.setBounds(200, 80, 300, 40);
        this.getContentPane().add(msLabel);
        msLabel.setVisible(true);
        client= new JButton("Clients");
        client.setFont(new Font("Tahoma", Font.PLAIN, 12));
        client.setBounds(250, 150, 100, 25);
        client.setBackground(Color.MAGENTA);
        this.getContentPane().add(client);
        client.setVisible(true);
        product = new JButton("Products");
        product.setFont(new Font("Tahoma", Font.PLAIN, 12));
        product.setBounds(250, 200, 100, 25);
        product.setBackground(Color.MAGENTA);
        this.getContentPane().add(product);
        product.setVisible(true);
        order = new JButton("Orders");
        order.setFont(new Font("Tahoma", Font.PLAIN, 12));
        order.setBounds(250, 250, 100, 25);
        order.setBackground(Color.MAGENTA);
        this.getContentPane().add(order);
        order.setVisible(true);
        this.setVisible(true);
    }

    public void setClientButtonActionListener(ActionListener a) {
        client.addActionListener(a);
    }
    public void setOrderButtonActionListener(ActionListener a) {
        order.addActionListener(a);
    }
    public void setProductButtonActionListener(ActionListener a) {
        product.addActionListener(a);
    }
}
