package org.example.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class EditClientFrame extends JFrame{
    protected JButton edit;
    protected JTextField nameField;
    protected JTextField ageField;
    protected JTextField idField;
    protected JTextField addressField;
    public EditClientFrame(){
        this.setBounds(100, 100, 650, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setBackground(Color.pink);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setLayout(null);
        JLabel label1 = new JLabel("Name");
        label1.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label1.setBounds(130, 170, 50, 25);
        this.getContentPane().add(label1);
        label1.setVisible(true);
        nameField = new JTextField();
        nameField.setBounds(200, 170, 250, 25);
        nameField.setBackground(Color.pink);
        this.getContentPane().add(nameField);
        nameField.setColumns(2);
        JLabel label = new JLabel("Id");
        label.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label.setBounds(150, 130, 30, 25);
        this.getContentPane().add(label);
        label.setVisible(true);
        idField = new JTextField();
        idField.setBounds(200, 130, 250, 25);
        idField.setBackground(Color.pink);
        this.getContentPane().add(idField);
        idField.setColumns(2);
        JLabel label2 = new JLabel("Age");
        label2.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label2.setBounds(130, 210, 50, 25);
        this.getContentPane().add(label2);
        label2.setVisible(true);
        ageField = new JTextField();
        ageField.setBounds(200, 210, 250, 25);
        ageField.setBackground(Color.pink);
        this.getContentPane().add(ageField);
        ageField.setColumns(2);
        JLabel label3 = new JLabel("Address");
        label3.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label3.setBounds(110, 250, 80, 25);
        this.getContentPane().add(label3);
        label3.setVisible(true);
        addressField = new JTextField();
        addressField.setBounds(200, 250, 250, 25);
        addressField.setBackground(Color.pink);
        this.getContentPane().add(addressField);
        addressField.setColumns(2);
        edit = new JButton("edit");
        edit.setFont(new Font("Tahoma", Font.PLAIN, 12));
        edit.setBounds(370, 350, 100, 25);
        edit.setBackground(Color.MAGENTA);
        this.getContentPane().add(edit);
        edit.setVisible(true);
        this.setVisible(true);
    }
    public void setEditButtonActionListener(ActionListener a) {
        edit.addActionListener(a);
    }
    public int getIdField(){
        return Integer.parseInt(idField.getText());
    }
    public String getNameField() {
        return nameField.getText();
    }
    public int getAgeField() {
        return Integer.parseInt(ageField.getText());
    }
    public String getAddressField() {
        return addressField.getText();
    }
}
