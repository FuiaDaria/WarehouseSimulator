package org.example.view;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
public class AddProductFrame extends JFrame{
    protected JTextField nameField;
    protected JTextField priceField;
    protected JTextField quantityField;
    protected JButton add;
    public AddProductFrame(){
        this.setBounds(100, 100, 650, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setBackground(Color.pink);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setLayout(null);
        JLabel label1 = new JLabel("Name");
        label1.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label1.setBounds(130, 150, 50, 25);
        this.getContentPane().add(label1);
        label1.setVisible(true);
        nameField = new JTextField();
        nameField.setBounds(200, 150, 250, 25);
        nameField.setBackground(Color.pink);
        this.getContentPane().add(nameField);
        nameField.setColumns(2);
        JLabel label2 = new JLabel("Price");
        label2.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label2.setBounds(130, 200, 50, 25);
        this.getContentPane().add(label2);
        label2.setVisible(true);
        priceField = new JTextField();
        priceField.setBounds(200, 200, 250, 25);
        priceField.setBackground(Color.pink);
        this.getContentPane().add(priceField);
        priceField.setColumns(2);
        JLabel label3 = new JLabel("Quantity");
        label3.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label3.setBounds(110, 250, 80, 25);
        this.getContentPane().add(label3);
        label3.setVisible(true);
        quantityField = new JTextField();
        quantityField.setBounds(200, 250, 250, 25);
        quantityField.setBackground(Color.pink);
        this.getContentPane().add(quantityField);
        quantityField.setColumns(2);
        add = new JButton("add");
        add.setFont(new Font("Tahoma", Font.PLAIN, 12));
        add.setBounds(370, 350, 100, 25);
        add.setBackground(Color.MAGENTA);
        this.getContentPane().add(add);
        add.setVisible(true);
        this.setVisible(true);
    }
    public void setAddButtonActionListener(ActionListener a) {
        add.addActionListener(a);
    }
    public String getNameField() {
        return nameField.getText();
    }
    public int getPriceField() {
        return Integer.parseInt(priceField.getText());
    }
    public int getQuantityField() {
        return Integer.parseInt(quantityField.getText());
    }

}
