package org.example.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class EditProductFrame extends JFrame{
    protected JButton edit;
    protected JTextField nameField;
    protected JTextField priceField;
    protected JTextField idField;
    protected JTextField quantityField;
    public EditProductFrame(){
        this.setBounds(100, 100, 650, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setBackground(Color.pink);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setLayout(null);
        JLabel label1 = new JLabel("Name");
        label1.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label1.setBounds(130, 170, 50, 25);
        this.getContentPane().add(label1);
        label1.setVisible(true);
        nameField = new JTextField();
        nameField.setBounds(200, 170, 250, 25);
        nameField.setBackground(Color.pink);
        this.getContentPane().add(nameField);
        nameField.setColumns(2);
        JLabel label = new JLabel("Id");
        label.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label.setBounds(150, 130, 30, 25);
        this.getContentPane().add(label);
        label.setVisible(true);
        idField = new JTextField();
        idField.setBounds(200, 130, 250, 25);
        idField.setBackground(Color.pink);
        this.getContentPane().add(idField);
        idField.setColumns(2);
        JLabel label2 = new JLabel("Price");
        label2.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label2.setBounds(130, 210, 50, 25);
        this.getContentPane().add(label2);
        label2.setVisible(true);
        priceField = new JTextField();
        priceField.setBounds(200, 210, 250, 25);
        priceField.setBackground(Color.pink);
        this.getContentPane().add(priceField);
        priceField.setColumns(2);
        JLabel label3 = new JLabel("Quantity");
        label3.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label3.setBounds(110, 250, 80, 25);
        this.getContentPane().add(label3);
        label3.setVisible(true);
        quantityField = new JTextField();
        quantityField.setBounds(200, 250, 250, 25);
        quantityField.setBackground(Color.pink);
        this.getContentPane().add(quantityField);
        quantityField.setColumns(2);
        edit = new JButton("edit");
        edit.setFont(new Font("Tahoma", Font.PLAIN, 12));
        edit.setBounds(370, 350, 100, 25);
        edit.setBackground(Color.MAGENTA);
        this.getContentPane().add(edit);
        edit.setVisible(true);
        this.setVisible(true);
    }
    public void setEditButtonActionListener(ActionListener a) {
        edit.addActionListener(a);
    }
    public int getIdField(){
        return Integer.parseInt(idField.getText());
    }
    public String getNameField() {
        return nameField.getText();
    }
    public int getPriceField() {
        return Integer.parseInt(priceField.getText());
    }
    public int getQuantityField() {
        return Integer.parseInt(quantityField.getText());
    }
}
