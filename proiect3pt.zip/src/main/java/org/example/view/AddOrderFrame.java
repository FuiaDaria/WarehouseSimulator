package org.example.view;
import org.example.model.Customer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import org.example.BLL.CustomerService;
public class AddOrderFrame extends JFrame{
    protected JTextField idcField;
    protected JTextField possible;
    protected JTextField idpField;
    protected JTextField quantityField;
    protected JButton add;
    CustomerService customerService = new CustomerService();
    public AddOrderFrame(){
        this.setBounds(100, 100, 650, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setBackground(Color.pink);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setLayout(null);
        /*JLabel label1 = new JLabel("client id");
        label1.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label1.setBounds(110, 150, 80, 25);
        this.getContentPane().add(label1);
        label1.setVisible(true);
        idcField = new JTextField();
        idcField.setBounds(200, 150, 250, 25);
        idcField.setBackground(Color.pink);
        this.getContentPane().add(idcField);
        idcField.setColumns(2);

        JLabel label2 = new JLabel("product id");
        label2.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label2.setBounds(110, 200, 80, 25);
        this.getContentPane().add(label2);
        label2.setVisible(true);
        idpField = new JTextField();
        idpField.setBounds(200, 200, 250, 25);
        idpField.setBackground(Color.pink);
        this.getContentPane().add(idpField);
        idpField.setColumns(2);
        JLabel label3 = new JLabel("quantity");
        label3.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label3.setBounds(110, 250, 80, 25);
        this.getContentPane().add(label3);
        label3.setVisible(true);
        quantityField = new JTextField();
        quantityField.setBounds(200, 250, 250, 25);
        quantityField.setBackground(Color.pink);
        this.getContentPane().add(quantityField);
        quantityField.setColumns(2);
        possible = new JTextField();
        possible.setBounds(200, 300, 300, 25);
        possible.setBackground(Color.pink);
        this.getContentPane().add(possible);
        possible.setColumns(2);
        possible.setVisible(true);*/
        ArrayList<Customer> clients = customerService.getAll();
        ComboBoxModel<Customer> comboBoxModel = new DefaultComboBoxModel<>(clients.toArray(new Customer[]{clients.get(0)}));
        JComboBox<Customer> comboBox = new JComboBox<>(comboBoxModel);
        this.getContentPane().add(comboBox);
        comboBox.setVisible(true);
        add = new JButton("add");
        add.setFont(new Font("Tahoma", Font.PLAIN, 12));
        add.setBounds(370, 350, 100, 25);
        add.setBackground(Color.MAGENTA);
        this.getContentPane().add(add);
        add.setVisible(true);
        this.setVisible(true);
    }
    public void setAddButtonActionListener(ActionListener a) {
        add.addActionListener(a);
    }
    public int getIdcField() {
        return Integer.parseInt(idcField.getText());
    }
    public int getIdpField() {
        return Integer.parseInt(idpField.getText());
    }
    public int getQuantityField() {
        return Integer.parseInt(quantityField.getText());
    }
    public void setPossibleField(String text){
        possible.setText(text);
    }

}

