package org.example.BLL.validators;

public interface Validate<T> {

    public void validate(T t);
}
