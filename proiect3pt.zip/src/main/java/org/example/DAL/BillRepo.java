package org.example.DAL;

import org.example.model.Bill;
public class BillRepo extends AbstractRepository<Bill>{

}

