package org.example.DAL;

import org.example.model.Product;

public class ProductRepo extends AbstractRepository<Product>{
}
