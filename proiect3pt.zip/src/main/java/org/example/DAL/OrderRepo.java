package org.example.DAL;

import org.example.model.Orders;

public class OrderRepo extends AbstractRepository<Orders>{
}
