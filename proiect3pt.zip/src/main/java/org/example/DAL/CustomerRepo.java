package org.example.DAL;

import org.example.model.Customer;

public class CustomerRepo extends AbstractRepository<Customer> {
}
