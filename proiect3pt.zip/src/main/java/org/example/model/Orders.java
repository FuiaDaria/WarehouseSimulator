package org.example.model;

public class Orders {
    private int id;
    private int productId;
    private int customerId;
    private int quantity;
    private int cost;

    public Orders(int customerId, int productId, int quantity, int cost) {
        this.productId = productId;
        this.customerId = customerId;
        this.quantity = quantity;
        this.cost = cost;
    }
    public Orders(){

    }

    public Orders(int id, int customerId, int productId, int quantity, int cost) {
        this.id = id;
        this.productId = productId;
        this.customerId = customerId;
        this.quantity = quantity;
        this.cost = cost;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", idc='" + customerId + '\'' +
                ", idp='" + productId + '\'' +
                ", quantity='" + quantity + '\'' +
                ", cost=" + cost +
                '}';
    }
}
