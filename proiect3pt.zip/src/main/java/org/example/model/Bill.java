package org.example.model;

public record Bill(int id, int orderID, int quantity){
}

