package org.example;

import org.example.controller.MainController;
import org.example.view.AddOrderFrame;
import org.example.view.MainFrame;

public class Main {
    public static void main(String[] args) {
       new MainController(new MainFrame());
        //new AddOrderFrame();
    }
}