package org.example.controller;

import org.example.view.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ProductController {
    public ProductController(ProductFrame frame){
        frame.setAddButtonActionListener(new AddButtonActionListener());
        frame.setDeleteButtonActionListener(new DeleteButtonActionListener());
        frame.setViewButtonActionListener(new ViewButtonActionListener());
        frame.setEditButtonActionListener(new EditButtonActionListener());
    }

    private class AddButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            new AddProductController(new AddProductFrame());
        }
    }

    private class EditButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            new EditProductController(new EditProductFrame());
        }
    }

    private class DeleteButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            new DeleteProductController(new DeleteProductFrame());
        }
    }

    private class ViewButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            new ViewProductController(new ViewProductFrame());
        }
    }
}
