package org.example.controller;
import org.example.BLL.CustomerService;
import org.example.model.Customer;
import org.example.view.ViewClientsFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ViewClientsController {
    ViewClientsFrame frame;
    CustomerService customerService;
    public ViewClientsController(ViewClientsFrame frame){
        this.frame = frame;
        customerService = new CustomerService();
        //customers = customerService.getAll();
        this.frame.setViewButtonActionListener(new ViewButtonActionListener());
    }
    private class ViewButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            ArrayList<Customer> customers;
            customers = customerService.getAll();
            System.out.println(customers.size());
            for (Customer client : customers) {
                System.out.println(client);
            }
        }
    }
}