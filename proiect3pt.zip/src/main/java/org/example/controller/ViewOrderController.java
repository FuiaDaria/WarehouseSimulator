package org.example.controller;
import org.example.BLL.OrderService;
import org.example.model.Orders;
import org.example.view.ViewOrderFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ViewOrderController {
    ViewOrderFrame frame;
    OrderService orderService;
    public ViewOrderController(ViewOrderFrame frame){
        this.frame = frame;
        orderService = new OrderService();
        this.frame.setViewButtonActionListener(new ViewButtonActionListener());
    }
    private class ViewButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            ArrayList<Orders> comenzi;
            comenzi = orderService.getAll();
            System.out.println(comenzi.size());
            for (Orders order : comenzi) {
                System.out.println(order);
            }
        }
    }
}
