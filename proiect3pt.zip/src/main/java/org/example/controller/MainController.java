package org.example.controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.example.view.*;
public class MainController {
    public MainController(MainFrame frame){
        frame.setClientButtonActionListener(new ClientButtonActionListener());
        frame.setProductButtonActionListener(new ProductButtonActionListener());
        frame.setOrderButtonActionListener(new OrderButtonActionListener());
    }

    private class ClientButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            new ClientController(new ClientFrame());

        }
    }
    private class ProductButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            new ProductController(new ProductFrame());

        }
    }
    private class OrderButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            new OrderController(new OrderFrame());

        }
    }
}
