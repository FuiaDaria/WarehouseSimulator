package org.example.controller;

import org.example.view.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class OrderController {
    public OrderController(OrderFrame frame){
        frame.setAddButtonActionListener(new AddButtonActionListener());
        frame.setDeleteButtonActionListener(new DeleteButtonActionListener());
        frame.setViewButtonActionListener(new ViewButtonActionListener());
        frame.setEditButtonActionListener(new EditButtonActionListener());
    }

    private class AddButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            new AddOrderController(new AddOrderFrame());
        }
    }

    private class EditButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            new EditOrderController(new EditOrderFrame());
        }
    }

    private class DeleteButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            new DeleteOrderController(new DeleteOrderFrame());
        }
    }

    private class ViewButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            new ViewOrderController(new ViewOrderFrame());
        }
    }
}
