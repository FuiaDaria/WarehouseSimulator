package org.example.controller;
import org.example.BLL.ProductService;
import org.example.model.Product;
import org.example.view.ViewProductFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ViewProductController {
    ViewProductFrame frame;
    ProductService productService;
    public ViewProductController(ViewProductFrame frame){
        this.frame = frame;
        productService = new ProductService();
        this.frame.setViewButtonActionListener(new ViewButtonActionListener());
    }
    private class ViewButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            ArrayList<Product> products;
            products = productService.getAll();
            for (Product produs : products) {
                System.out.println(produs);
            }
        }
    }
}
